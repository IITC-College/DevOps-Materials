#!/bin/bash
# Web Application Start Script
# This script starts the web application server

echo "Starting web application..."
echo "Initializing server..."
echo "Server started on port 8080"
echo "Web application is now running!"
