#!/bin/bash
# Reference Script
# This script is provided as a reference for correct permissions

echo "Reference script with proper permissions"
echo "Permissions: -rwxr-xr-x"
echo "Owner: read, write, execute"
echo "Group: read, execute"
echo "Others: read, execute"
