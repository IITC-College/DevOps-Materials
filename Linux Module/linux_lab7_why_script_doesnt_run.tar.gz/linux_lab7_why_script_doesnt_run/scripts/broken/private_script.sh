#!/bin/bash
# Private Script
# This script should only be executable by the owner

echo "This is a private script"
echo "Only the owner should be able to run this"
echo "Use chmod u+x to add execute permission for owner only"
