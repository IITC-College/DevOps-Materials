#!/bin/bash
# Shared Tool Script
# This tool should be accessible by the team

echo "Shared tool script"
echo "This tool is used by the development team"
echo "Team members should be able to execute this"
