#!/bin/bash
# Team Script
# Owner: bob
# Group: developers
# Permissions: rwxrwx--- (owner: read+write+execute, group: read+write+execute, others: none)

# This script can be run by both the owner and group members
echo "Team collaboration script"
echo "Both owner and group members can execute this"
