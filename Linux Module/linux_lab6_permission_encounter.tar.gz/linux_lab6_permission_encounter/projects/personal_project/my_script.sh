#!/bin/bash
# Personal Script
# Owner: alice
# Group: developers
# Permissions: rwx------ (owner: read+write+execute, group: none, others: none)

# This is a personal script that only the owner can run
echo "This is a private script"
echo "Only the owner can execute this"
