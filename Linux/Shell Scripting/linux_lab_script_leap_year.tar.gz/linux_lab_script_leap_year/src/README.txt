This lab does not require starter files. All work is done in scripts you create in the lab directory.
