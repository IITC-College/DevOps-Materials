#!/bin/bash
# Simple Hello World Script
# This script demonstrates a basic script that needs execute permission

echo "Hello, World!"
echo "This script is now working!"
echo "You successfully added execute permission with chmod +x"
