#!/bin/bash
# Backup Script
# This script simulates a backup operation

echo "Starting backup process..."
echo "Backing up important files..."
echo "Backup completed successfully!"
echo "Files saved to backup directory"
