#!/bin/bash
# Web Application Stop Script
# This script stops the web application server

echo "Stopping web application..."
echo "Shutting down server..."
echo "Server stopped successfully"
