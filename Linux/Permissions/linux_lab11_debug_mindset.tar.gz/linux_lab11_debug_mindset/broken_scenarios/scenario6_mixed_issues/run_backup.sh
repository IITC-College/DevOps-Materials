#!/bin/bash
# Backup script

echo "Backup completed successfully!"
echo "This script creates a backup of important data."
