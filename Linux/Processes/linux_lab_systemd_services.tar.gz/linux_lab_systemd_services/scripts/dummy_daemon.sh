#!/bin/bash
# Simple daemon for lab-demo.service – stays running so students can practice start/stop/restart.
while true; do sleep 1; done
