#!/bin/bash
# Level 1, Clue 2: No setup needed - students use existing system processes.
echo "ℹ No setup needed for Level 1, Clue 2 - you'll use existing system processes."
exit 0
