#!/bin/bash
# Level 1, Clue 2: No cleanup needed - no processes were started.
echo "ℹ No cleanup needed for Level 1, Clue 2."
exit 0
