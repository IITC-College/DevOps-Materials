#!/bin/bash
# Level 1, Clue 1: No setup needed - students view general system logs.
echo "ℹ No setup needed for Level 1, Clue 1 - you'll view general system logs."
exit 0
